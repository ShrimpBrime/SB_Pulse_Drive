SB PULSE DRIVE - VERSION 1.2

VERSION 1.2 - FINISHED PORTABLE RELEASE
Version 1.2 promotes the completed rework to the finished public release. It
includes the verified Extreme accuracy model, equal-weight Multi-Drive Average,
2s/5s comparisons, conservative drive identification, transparent temporary-file
documentation, Copy Results, expandable results, and remembered window layout.

VERSION 1.1 - DRIVE INFORMATION AND MULTI-TACH REWORK
Version 1.1 sharpens SB Pulse Drive's original purpose as the activity companion
for SB SSD Temps. The new Multi-Tach activity preset configures a short,
simultaneous, read-only wake pulse for every selected drive. REFRESH updates the
drive table without restarting the application.

The drive table concentrates on useful identity and volume details. Drive letter
and volume label share one column; Windows Storage media type is shown as SSD,
HDD, SCM, or Unknown. Interface uses Windows Storage bus information only when
one physical device matches the Windows disk number, then falls back to the
generic Windows interface value. The app never guesses from a model name.
Inconsistent powered-on-hours and start/stop-counter columns remain excluded.

Temperature monitoring intentionally remains outside SB Pulse Drive. SB SSD
Temps remains the temperature and multi-tach display application.

VERSION 1.0 - INITIAL PUBLIC RELEASE
Version 1.0 promotes the tested Preview v0.15 feature set without functional
changes. This is the first feature-frozen public release candidate. It provides
controlled multi-drive activity pulses, simultaneous or sequential scheduling,
read-only and temporary-file write modes, ordered results, available Windows
storage counters, persistent visual themes, screenshots, and built-in support
documentation.

PREVIEW v0.15
Completed results now follow the same top-to-bottom order as the selected drives
in the drive table. Simultaneous pulses may still finish internally in any
order, but that timing no longer rearranges the displayed result lines.

BLACK BG now remains black while the smooth color slider changes the accent
color. SAVE THEME stores the chosen background preset and accent for future
starts; CLEAR THEME removes that saved preference and restores the original
defaults. The settings stay local to the current Windows user.

SUPPORT now reads documentation explicitly as UTF-8 to prevent stray encoding
characters around the copyright and trademark notices.

PREVIEW v0.14
Earlier counter experiments were removed from the current interface because
Windows did not expose consistent values across all tested storage paths.

COLORS now provides three presets in addition to the smooth spectrum control:
Black + White, White Theme, and Black Background. FONT remains locked to the
safe default 9-point size while allowing a different font family.

PREVIEW v0.13
FONT now changes only the font family while locking all normal interface text to
the original 9-point size. This prevents oversized text from overlapping labels,
tables, and buttons. COLORS now includes a Black + White preset in addition to
the smooth accent spectrum.

Life remaining detection now matches Win32 disks to Windows physical-disk
objects by device ID, serial number, and model/friendly name, then queries the
matched disk's reliability counter directly. This corrects the earlier mapping
that caused supported devices to display N/A. A genuine unsupported or hidden
wear counter still displays N/A.

PREVIEW v0.12
Visual customization has been moved behind compact COLORS and FONT buttons,
leaving the main interface cleaner. COLORS opens the smooth full-spectrum
accent control. SUPPORT opens this complete, scrollable information and help
guide inside the application.

PREVIEW v0.11
The drive table now displays Life remaining directly after Model. The value is
calculated as 100 minus the read-only Wear percentage exposed by Windows
storage reliability counters. Drives and adapters that do not expose a usable
counter display N/A rather than an estimated value.

A smooth full-spectrum accent slider and a safe-size font chooser provide
session-only visual customization without changing drive activity. Completed
transfer rates are shown in bold gold so MB/s and GB/s results stand apart from
the surrounding status text.

PREVIEW v0.10 UI STABILITY
The drive list now remains enabled and dark while a pulse runs instead of
switching to Windows' bright disabled-control rendering. Drive selections are
temporarily locked without changing the list's visual state. Double buffering
reduces repaint flicker, and the table grid has been removed for a cleaner,
less cluttered drive-selection area. Run controls are locked until cleanup is
complete so the active job retains a stable configuration.

PREVIEW v0.09 ENGINE
Extreme READ now uses four independent unbuffered workers and aggregates their
throughput. When one temporary source is used, each worker reads a separate
aligned region; Read Only distributes available source files across workers.
This removes the earlier queue-depth-1 application bottleneck that limited fast
NVMe reads to roughly 2.0-2.5 GB/s in initial testing. Filesystems that reject
unbuffered I/O retain the compatible buffered fallback.

Extreme WRITE now honors the complete selected phase duration. It maintains a
bounded 1 GiB temporary-file footprint and overwrites that payload repeatedly
until time expires. A four-worker queued write path pushes capable drives harder.
Total write traffic can therefore exceed 1 GiB per drive.
The interface now offers Simultaneous scheduling for combined system activity
or One drive at a time scheduling for cleaner individual peak testing.

Extreme mode removes the software transfer-rate limit and requests peak
bandwidth from every selected physical drive. Write modes retain a hard 1 GiB
temporary-file footprint per drive, require at least 1.25 GB free, display a
clear warning, and still perform automatic cleanup. Extreme Read Only remains
non-writing and applies unthrottled reads to suitable existing files.

Read + Write now runs as two distinct phases instead of launching both jobs at
the same time. WRITE creates the declared temporary file first, then READ uses
that known file with unbuffered Windows I/O where supported. The selected phase
duration is applied once to WRITE and once to READ. Light, Medium,
and Heavy limits now govern both phases consistently. Per-drive results use a
fixed internal 100 ms measurement window and report measured rate plus total
bytes processed. Changing phase duration no longer changes the measurement
cadence.

Read Only continues to perform zero intentional writes. It rotates through
suitable existing readable files and reports clearly when none are available.
Read + Write no longer depends on finding an unrelated existing file. Its
temporary WRITE payload becomes its explicit READ source and is removed after
the run. Read Only remains separate and never creates that payload.

PURPOSE
SB Pulse Drive creates short, controlled activity on multiple physical drives
at the same time. It is intended for private testing alongside SB SSD Temps so
the full and miniature activity gauges can be observed together.

SAFETY MODEL
- Mounted local volumes only
- One selected volume per Windows physical disk
- No raw-disk access
- No formatting, partitioning, optimization, or permanent files
- Unique temporary directory on each selected volume
- Automatic cleanup after completion, cancellation, or handled failure
- Estimated maximum write traffic displayed before starting
- Drives with less than 250 MB free are blocked
- Extreme write modes require 1.25 GB free and use four initialized files,
  bounded to a combined 1 GiB per drive
- Extreme read mode uses four aligned, unbuffered workers with no cached fallback
- Simultaneous and One drive at a time scheduling modes
- Stable double-buffered drive list with selections locked during activity
- Combined drive-letter/volume-label identity
- Conservative Windows-reported media type, interface, and firmware details
- COLORS dialog with a full-spectrum accent slider and interface font chooser
- Bold gold transfer-rate highlighting in completed results
- Built-in SUPPORT window containing information, help, and troubleshooting

IMPORTANT
This application performs real reads and writes. Back up important information
before using any storage stress or activity tool. Do not disconnect, power off,
or remove a selected drive during a pulse. SB Pulse Drive is intended for short,
controlled activity snapshots and should not be treated as a storage-validation
or certification tool.

RUN
PUBLIC SINGLE-EXE BUILD
1. Extract the entire release-candidate ZIP on a Windows 10/11 test system.
2. Double-click Build_SB_Pulse_Drive_Portable.cmd.
3. The builder creates SB_Pulse_Drive_v1.2_UNSIGNED.exe in the same folder.
4. Test that exact EXE before signing it. Do not rebuild after signing.

FOLDER BUILD
1. Extract the entire ZIP.
2. Double-click Run_SB_Pulse_Drive.cmd.
3. Approve administrator access.
4. Review the detected physical disks and selected volumes.
5. Choose a mode, phase duration, and activity level.
6. For a write mode, read and select the temporary-file acknowledgement.
7. Press PULSE SELECTED DRIVES.

DEFAULT PULSE
Read + Write, 2 seconds per phase, Medium activity. The default combined run is
approximately four seconds: a two-second WRITE phase followed by a two-second
READ phase. Medium limits each phase to about 64 MB per second per selected
physical drive and limits writes to roughly 128 MB per drive. Reported rates are
application-level activity measurements, not formal benchmark scores, and may
still be influenced by Windows caching, controllers, adapters, RAID, and drive
firmware.

Manual pulse results remain activity snapshots rather than formal benchmark
scores. SB Pulse benchmark averages should be compared only when the app version,
preset, selected drive set, cooling state, and major background activity match.

CONTROLS
- Drive table: Selects the mounted volume used for each detected physical disk.
- Mode: Selects Read + Write, Read Only, or Write Only operation.
- Phase duration: Sets the requested time for each applicable phase.
- Activity level: Selects a limited rate or the unthrottled Extreme engine.
- 2s EXTREME BENCH: Dedicated button that fixes Read + Write, Simultaneous,
  Extreme, and two seconds per phase immediately before launch.
- 5s EXTREME BENCH: Separate dedicated button that fixes Read + Write,
  Simultaneous, Extreme, and five seconds per phase immediately before launch.
- CLEAR RESULTS: Removes saved 2s/5s benchmark comparison values. Saved values
  also reset naturally when the application is closed and restarted.
- Schedule: Runs selected drives simultaneously or one physical disk at a time.
- COLORS: Opens the smooth accent-color control plus Black + White, White Theme,
  and Black Background presets.
- FONT: Selects a font family while retaining the fixed 9-point interface size.
- SUPPORT: Opens the two-tab operation, compatibility, help, and limits guide.
- ABOUT: Opens the project identity, version, purpose, and Chiller Cube panel.
- PULSE SELECTED DRIVES: Starts the configured operation.
- STOP: Requests cancellation and waits for temporary-file cleanup.
- APP SCREENSHOT: Saves an image of the application window.
- DESKTOP SCREENSHOT: Saves the complete Windows virtual desktop, including all
  attached displays, to the SB Pulse Drive Screenshots folder in Pictures.
- COPY RESULTS: Copies the displayed results with the app and Windows versions,
  timestamp, actual run settings, and selected drive models.

MODES
Read + Write performs a WRITE phase followed by a READ phase. The temporary
write payload becomes the verified read source and is deleted after completion.

Read Only scans suitable existing files and makes no intentional writes. A
drive may report that no suitable readable source was found.

Write Only creates bounded temporary data, measures the requested activity,
and removes the temporary directory after the run.

ACTIVITY LEVELS
- Multi-Tach: approximately 4 MB/s per active drive with a one-second,
  simultaneous Read Only preset.
- Light: approximately 16 MB/s per active drive.
- Medium: approximately 64 MB/s per active drive.
- Heavy: approximately 256 MB/s per active drive.
- Extreme: removes the application rate limit and uses queued I/O to request a
  short burst of high activity. Hardware, filesystem, cache, and controller
  behavior still determine the observed result.

BENCHMARK BUTTONS AND COMBINED AVERAGE
- 2s EXTREME BENCH: two-second WRITE plus two-second READ without a software
  rate limit.
- 5s EXTREME BENCH: five-second WRITE plus five-second READ without a software
  rate limit.

Both buttons use Simultaneous scheduling. For each selected drive, its read
and write phase averages are converted to decimal MB/s. Average Read and Average
Write give every selected physical drive equal weight. Final Multi-Drive Average is
the midpoint of those two averages and is displayed in decimal MB/s or GB/s. A
slower HDD therefore lowers a mixed system result instead of being hidden by a
fast NVMe. The final average is unavailable unless every selected drive returns
both verified phase averages.

For N selected physical drives, the displayed calculation is:
- Average Read = sum of all verified drive read rates / N
- Average Write = sum of all verified drive write rates / N
- Final Multi-Drive Average = (Average Read + Average Write) / 2

Rates are calculated from bytes transferred divided by the measured phase time.
One MB is 1,000,000 bytes and the display changes to GB/s at 1,000 MB/s. This is
an equal-weight average across drives, not their aggregate bandwidth.

EXTREME I/O ACCURACY MODEL
Extreme Write uses four independent temporary files per selected drive. Each
file grows only through completed real writes, up to 256 MiB, and then overwrites
only its initialized contents. The app does not pre-size an unwritten 1 GiB file.
This prevents NTFS zero-filled unwritten regions from being counted as physical
drive reads. The combined footprint remains bounded at 1 GiB per drive.

Extreme Read uses four aligned unbuffered workers and reads only those verified
initialized files. The buffered Windows file-cache fallback is prohibited for
Extreme benchmark results. If all four unbuffered workers cannot operate, the
drive reports a failure and the Multi-Drive Average is unavailable rather than
displaying a misleading cached result.

Extreme rates are full-phase averages rather than the highest 100 ms scheduling
sample. Throughput uses decimal MB/s and GB/s, matching storage-manufacturer
specifications. Total transferred quantities use binary MiB and GiB labels.

The latest successful 2s Extreme average remains visible after a 5s Extreme
run, allowing the two burst lengths to be compared directly. Re-running either
benchmark replaces only that duration's saved value. CLEAR RESULTS removes both
saved values; they are not written to disk and therefore also clear on restart.

The five-second Extreme average is the recommended comparison result because its
longer phases reduce the influence of startup timing and very short cache
bursts. The two-second result is best treated as a quick burst average.

SCHEDULING
Simultaneous starts activity on all selected physical disks together. This is
useful for observing combined system activity but can introduce contention.

One drive at a time isolates each selected physical disk in sequence. This is
usually the cleaner choice when comparing individual drive response.

RESULTS
Limited-mode rates are measured from application-level completed I/O using a
fixed internal 100 ms measurement window. Extreme uses complete-phase averages.
MB/s and GB/s values are emphasized in bold gold.
The report also includes total bytes processed and any cleanup or source-file
messages. Manual results are snapshots; only the two Extreme benchmark buttons generate
Average Read, Average Write, and Final Multi-Drive Average results.

WINDOW LAYOUT
The drive table and operating controls remain fixed when the main window grows.
Additional height is assigned to the results panel. The last normal window size,
position, and maximized state are saved at exit and restored within the usable
bounds of an available display.

INTENDED TESTING SCOPE
SB Pulse Drive is designed to create short-duration HDD and SSD loads so drive
activity, tachometer response, and mixed-system behavior can be checked while
keeping temporary writes and drive wear to a practical minimum during testing.

The benchmark averages are useful perks for comparing repeat runs under similar
conditions. They do not represent deep analysis or comprehensive validation of
drive speed, sustained performance, cache exhaustion, endurance, health, data
integrity, or long-duration thermal behavior. SB Pulse Drive is a testing app
with lightweight benchmark features, not a replacement for a dedicated storage
benchmark, diagnostic suite, endurance test, or validation workload.

TEMPORARY FILES AND CLEANUP
For a selected D: volume, write modes create this uniquely named directory in
the root of that same volume:

  D:\SB_Pulse_Drive_Temp_<32-character GUID>\

The random GUID prevents a run from reusing or replacing an existing folder.
Light, Medium, and Heavy create write-pulse.tmp. Its maximum length is the
selected decimal MB/s limit multiplied by the phase duration. Read + Write uses
that file as its separate read source.

Extreme creates extreme-write-0.tmp through extreme-write-3.tmp. Each grows
only through completed writes to at most 256 MiB, for a combined initialized
footprint of at most 1 GiB per selected drive. It then overwrites only initialized
contents for the remainder of the phase, so total traffic may exceed 1 GiB.

The payload is a pseudo-random byte buffer generated in memory for the run. It
is not copied from user documents or other existing files and contains no
executable program. The app requests write-through operation and a final flush;
the drive or controller may still use internal caching.

Normal completion, STOP, and handled failures request automatic deletion of the
files and unique directory. Read Only creates none of these temporary files and
does not intentionally modify the existing files it reads.

If power is lost or the process is forcibly terminated, a temporary folder may
remain. Confirm no pulse is running before deleting an abandoned
SB_Pulse_Drive_Temp_* temporary folder.

TROUBLESHOOTING
- No drives appear: Confirm Windows assigned a drive letter and the volume is
  mounted and accessible, then restart the application as administrator.
- A result is lower than expected: Use One drive at a time, close competing disk
  activity, allow the drive to cool, and repeat. Short bursts naturally vary.
- Read Only reports no source: The volume did not contain a suitable accessible
  existing file. Use another volume or Read + Write if temporary writes are OK.
- A temporary folder remains: Close the app, confirm disk activity has stopped,
  and remove only the clearly named SB_Pulse_Drive temporary folder.
- The app does not open: Extract the complete ZIP, keep all files together, and
  run Run_SB_Pulse_Drive.cmd. Review any displayed PowerShell error message.
- Security software blocks the preview: Do not bypass organizational policy.
  Verify the package source and checksum, then request administrator guidance.

COMPATIBILITY AND LIMITATIONS
SB Pulse Drive targets 64-bit Windows 10 and Windows 11. It works with mounted
local volumes that Windows can map to physical disks. USB bridges, PCIe cards,
RAID, Storage Spaces, encryption, virtualization, and proprietary controllers
may hide identity or performance details or may report aggregate data.
Only one mounted volume per detected physical disk is selected by the app.

Observed throughput can be affected by Windows caching, controller cache,
filesystem behavior, thermal throttling, background work, firmware, interface
limits, compression, and the size or availability of source files.

PRIVACY
The application performs its drive discovery, activity, and result reporting
locally. It does not intentionally upload drive information or test results.
Screenshots are created only when the user selects the screenshot control.

HELP AND SUPPORT
Project support forum: https://sb-ssd-temps.proboards.com/

When requesting help, include:
1. SB Pulse Drive version.
2. Windows version and whether the app was run as administrator.
3. Drive model, interface or adapter, filesystem, and available free space.
4. Selected mode, phase duration, activity level, and schedule.
5. The complete result text or a screenshot.
6. Any PowerShell, Windows, or security-software error message.

Do not post serial numbers, device IDs, account details, encryption recovery
keys, or other information you do not want made public.

COPYRIGHT AND TRADEMARK NOTICE
© 2026 Jon Bauer. All rights reserved.

ShrimpBrime™ is an unregistered trademark claimed by Jon Bauer and is used
as the source-identifying brand for this project. In displayed or formatted
material it may appear as ShrimpBrime™. The TM symbol records a trademark claim;
it does not represent federal registration. The registered trademark symbol is
not used.

Copyright applies to the original source code, interface artwork and layout
expression, written documentation, and original project media. This notice does
not claim ownership of general ideas, facts, storage-testing concepts, methods
of operation, Windows interfaces, or third-party components. Third-party names
and components remain the property of their respective owners and are governed
by their applicable licenses. This notice records an ownership claim and is not
a substitute for registration or legal advice.

DISCLAIMER
Use at your own risk. Storage activity always carries some risk of data loss,
unexpected disconnection, device failure, or interaction with other software.
Back up important data first. The software is provided without a guarantee of
performance, compatibility, drive-health accuracy, or fitness for a particular
purpose.
